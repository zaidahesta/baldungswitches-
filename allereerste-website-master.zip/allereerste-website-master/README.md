# M’n Allereerste Website!

Zie [arthurweststeijn.github.io/allereerste-website](https://arthurweststeijn.github.io/allereerste-website/).

Voorbeeldwebsite voor collegereeks <a href="https://osiris.uu.nl/osiris_student_uuprd/OnderwijsCatalogusSelect.do?selectie=cursus&collegejaar=2020&taal=nl&cursus=GKRMV17021">Cultural transfer I:
Premodern Sources in Modern Contexts</a>.
